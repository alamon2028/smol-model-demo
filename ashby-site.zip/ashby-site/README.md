# Ashby — the Butler Cat

A one-eyed grey cat who behaves like a British butler, voiced by a small language model
([Qwen2.5-0.5B-Instruct](https://huggingface.co/onnx-community/Qwen2.5-0.5B-Instruct), Apache-2.0)
running entirely in the visitor's browser with [Transformers.js](https://huggingface.co/docs/transformers.js).
WebGPU is used where available, with a WASM (CPU) fallback.

## Files

| File | Purpose |
|---|---|
| `index.html` | The page: styles, chat UI, character prompt, settings |
| `worker.js` | Loads the model and generates replies off the main thread |
| `.nojekyll` | Tells GitHub Pages to serve the files as-is, without Jekyll |

## Deploy to GitHub Pages

1. Create a new public repository and upload these three files to the root of the `main` branch
   (`.nojekyll` is a hidden file; on the web uploader, drag it in along with the others).
2. In the repository, go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, and save.
4. After a minute or two the site is live at `https://<your-username>.github.io/<repo-name>/`.

The page works at a project URL (`/repo-name/`) or a user site root; all paths are relative.

## Notes

- **Download size:** about 483 MB on most WebGPU browsers (786 MB on WebGPU without 16-bit
  float support, 512 MB on the WASM fallback). The model comes from Hugging Face, not from
  GitHub, so it does not count against GitHub Pages' size or bandwidth limits.
- **Downloaded once:** weights are stored in the browser's Cache Storage, and the page asks the
  browser to keep that storage persistent. Clearing site data removes them.
- **Context length:** only the last 3 exchanges are sent to the model (`MAX_EXCHANGES`), with
  each message clipped to 600 characters (`MAX_CHARS_PER_MSG`). Both are at the top of the
  script in `index.html`, along with the character prompt (`SYSTEM_PROMPT`) and generation settings.
- **WASM speed:** GitHub Pages can't send the cross-origin isolation headers that multi-threaded
  WASM needs, so the CPU fallback runs single-threaded. WebGPU is unaffected.
- **Local testing:** open it through a local server (for example `python3 -m http.server`),
  not by double-clicking the file.
