// Ashby's model worker: loads the model and generates replies off the main thread,
// so the page stays responsive. Loaded as a module worker by index.html.
import { pipeline, TextStreamer, InterruptableStoppingCriteria, env }
  from "https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1";

env.allowLocalModels = false;   // GitHub Pages doesn't host the weights; always fetch from Hugging Face
env.useBrowserCache = true;     // weights are kept in the browser's Cache Storage after the first download

let generator = null;
const stopper = new InterruptableStoppingCriteria();
const fileProgress = new Map();

function onProgress(p) {
  if (p.status === "progress" && p.file) {
    fileProgress.set(p.file, { loaded: p.loaded || 0, total: p.total || 0 });
  } else if (p.status === "done" && p.file) {
    const f = fileProgress.get(p.file);
    if (f) f.loaded = f.total;
  } else return;
  let loaded = 0, total = 0;
  for (const f of fileProgress.values()) { loaded += f.loaded; total += f.total; }
  self.postMessage({ type: "progress", loaded, total });
}

async function load({ modelId, device, dtype, fallback }) {
  try {
    generator = await pipeline("text-generation", modelId, { device, dtype, progress_callback: onProgress });
    // Warm-up: compiles WebGPU shaders now, so the first real reply isn't slow.
    self.postMessage({ type: "warming" });
    await generator([{ role: "user", content: "Hi" }], { max_new_tokens: 1 });
    self.postMessage({ type: "ready", device, dtype });
  } catch (err) {
    if (fallback) {
      self.postMessage({ type: "fallback", reason: String(err?.message || err), to: fallback });
      fileProgress.clear();
      return load({ modelId, ...fallback, fallback: null });
    }
    self.postMessage({ type: "error", message: String(err?.message || err) });
  }
}

async function generate({ messages, options }) {
  stopper.reset();
  let text = "";
  const streamer = new TextStreamer(generator.tokenizer, {
    skip_prompt: true,
    skip_special_tokens: true,
    callback_function: (t) => { text += t; self.postMessage({ type: "token", text }); },
  });
  try {
    await generator(messages, { ...options, streamer, stopping_criteria: stopper });
    self.postMessage({ type: "done", text });
  } catch (err) {
    self.postMessage({ type: "error", message: String(err?.message || err), during: "generate" });
  }
}

self.onmessage = (e) => {
  const m = e.data;
  if (m.type === "load") load(m);
  else if (m.type === "generate") generate(m);
  else if (m.type === "stop") stopper.interrupt();
};
